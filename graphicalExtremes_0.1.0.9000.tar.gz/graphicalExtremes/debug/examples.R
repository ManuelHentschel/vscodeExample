
set.seed(1)

G <- generate_random_integer_Gamma(5, 2, 0.1)

g <- igraph::make_ring(5)

G2 <- complete_Gamma(G, g)

# g <- igraph::make_full_graph(4)
# g <- igraph::add.vertices(g, 1)
# g <- igraph::add.edges(g, c(5,3,5,4))


# A <- igraph::as_adjacency_matrix(g, sparse = FALSE)
# diag(A) <- 1

# G[A == 0] <- NA

# G2 <- complete_Gamma(G, g)

G <- rbind(
  c(0, 5, 7, 6, 6),
  c(5, 0, 14, 15, 13),
  c(7, 14, 0, 5, 5),
  c(6, 15, 5, 0, 6),
  c(6, 13, 5, 6, 0)
)

# complete_Gamma(G)
