
# set.seed(1)

tol <- 1e-5

pdet <- function(M){
  ev <- eigen(M)$values
  prod(ev[abs(ev) > tol])
}

d <- floor(runif(1, 5, 20))

print(d)

m <- generate_random_model(d, graph_type = 'general')

P <- Gamma2Theta(m$Gamma)

print(pdet(Gamma2Theta(m$Gamma)))

for(k in 1:d){
  print(det(Gamma2Theta(m$Gamma, k=k)))
}

print((d * det(Gamma2Theta(m$Gamma, k=k)) - pdet(Gamma2Theta(m$Gamma))) / pdet(Gamma2Theta(m$Gamma)))
