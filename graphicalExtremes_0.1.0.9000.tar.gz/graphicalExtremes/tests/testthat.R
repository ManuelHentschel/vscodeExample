library(testthat)
library(graphicalExtremes)

test_check("graphicalExtremes")
